/* ─────────────────────────────────────────────────────────────
   คลังข่าวสารของ VFOODS — ไฟล์นี้คือ "สารบัญข่าว" ไฟล์เดียวของทั้งเว็บ

   โครงสร้างโฟลเดอร์
     news/current/<slug>/   = รูปของ 3 ข่าวปัจจุบัน (ที่โชว์หน้า news.html)
     news/archive/<slug>/   = รูปของข่าวเก่าทั้งหมด (โชว์ในหน้า news-archive.html)
     news/news-index.js     = ไฟล์นี้ (ข้อความ + ลำดับ + พาธรูปของทุกข่าว)

   ★ ไม่ต้องแก้ไฟล์นี้ด้วยมือ ★
   ใช้โปรแกรมอัปเดตข่าวที่ admin/news-admin.html แทน:
   เปิด → แก้ข้อความ/ใส่รูป → กด "ส่งออกเป็น .zip" → ส่งไฟล์ zip ให้คนดูแลเว็บ
   → แตกไฟล์ zip ทับที่โฟลเดอร์เว็บ (ทับโฟลเดอร์ news/) → commit + push
   ───────────────────────────────────────────────────────────── */
window.NEWS_INDEX = {
  /* 3 ข่าวปัจจุบัน — โชว์เป็นการ์ดใหญ่ข้างฟีด Facebook บนหน้า news.html */
  current: [
    {
      slug: "new-mascot-2026",
      tag: "New Mascot",
      title: "เปิดตัว New Mascot ของวาไรตี้ฟู้ดส์",
      date: "สิงหาคม 2026",
      text: "จากชิ้นขนมแสนอร่อย มาเป็นตัวการ์ตูนน่ารักสดใส พร้อมหมวกสีส้มโลโก้ V ที่พร้อมเดินทางลุยทุกกิจกรรม พาลูกค้าแสนน่ารักของเราไปหาขนมแสนอร่อยหลากหลาย สไตล์วาไรตี้ฟู้ดส์ในทุกๆ วัน",
      cover: "news/current/new-mascot-2026/cover.png",
      body: [
        "จากชิ้นขนมแสนอร่อย มาเป็นตัวการ์ตูนน่ารักสดใส พร้อมหมวกสีส้มโลโก้ V ที่พร้อมเดินทางลุยทุกกิจกรรม พาลูกค้าแสนน่ารักของเราไปหาขนมแสนอร่อยหลากหลาย สไตล์วาไรตี้ฟู้ดส์ในทุกๆ วัน"
      ],
      images: [
        { src: "news/current/new-mascot-2026/p-mtmclgcx-1.jpg", caption: "ทดสอบคำบรรยาย" }
      ]
    },
    {
      slug: "thaifex-2026",
      tag: "กิจกรรม",
      title: "VFOODS ในงาน THAIFEX 2026",
      date: "พฤษภาคม 2026",
      text: "พาชมความอลังการของบูธ VFOODS ในงาน THAIFEX 2026 เปิดตัวสินค้าใหม่ พร้อมสินค้าหลากหลายจัดแสดงโชว์ เพื่อรอต้อนรับลูกค้าทั้งในและต่างประเทศที่สนใจเข้ามาสั่งผลิต OEM สินค้า",
      cover: "news/current/thaifex-2026/cover.jpg",
      body: [
        "พาชมความอลังการของบูธ VFOODS ในงาน THAIFEX 2026 เปิดตัวสินค้าใหม่ พร้อมสินค้าหลากหลายจัดแสดงโชว์ เพื่อรอต้อนรับลูกค้าทั้งในและต่างประเทศที่สนใจเข้ามาสั่งผลิต OEM สินค้า"
      ],
      images: [],
      link: "https://www.facebook.com/share/p/1JDN2hptCu/"
    },
    {
      slug: "tiktok-shop-awards-2026",
      tag: "รางวัล",
      title: "VFOODS คว้ารางวัล TikTok Shop Awards 2026",
      date: "สิงหาคม 2026",
      text: "ทีม E-Commerce ของ VFOODS ไม่ธรรมดา คว้ารางวัลยอดขายสูงสุดในหมวด Food & Beverage บนช่องทาง TikTok",
      cover: "news/current/tiktok-shop-awards-2026/cover.jpg",
      body: [
        "ทีม E-Commerce ของ VFOODS ไม่ธรรมดา คว้ารางวัลยอดขายสูงสุดในหมวด Food & Beverage บนช่องทาง TikTok",
        "VFOODS ขอขอบคุณลูกค้าทุกท่านที่ไว้วางใจและสั่งซื้อสินค้าของเรา จนติดอันดับ 1 บนช่องทาง TikTok"
      ],
      images: []
    }
  ],

  /* ข่าวย้อนหลัง — โชว์ในหน้า news-archive.html และท้ายหน้าข่าวแต่ละข่าว */
  archive: [
    {
      slug: "factory-expansion-2025",
      tag: "ประกาศ",
      title: "ขยายโรงงานผลิตรองรับดีมานด์ที่เพิ่มขึ้น",
      date: "ตุลาคม 2025",
      text: "",
      cover: "",
      body: [],
      images: []
    },
    {
      slug: "matcha-wafer-2025",
      tag: "NPD",
      title: "เวเฟอร์รสใหม่! มัทฉะจากญี่ปุ่น",
      date: "กันยายน 2025",
      text: "",
      cover: "news/archive/matcha-wafer-2025/cover.jpg",
      body: [],
      images: []
    },
    {
      slug: "fried-snacks-2025",
      tag: "NPD",
      title: "Fried Snacks หมวดหมู่ใหม่ที่รอคอย",
      date: "มิถุนายน 2025",
      text: "",
      cover: "news/archive/fried-snacks-2025/cover.jpg",
      body: [],
      images: []
    }
  ]
};
